<?php

// BEGIN iThemes Security - Do not modify or remove this line
// iThemes Security Config Details: 2
define( 'DISALLOW_FILE_EDIT', true ); // Disable File Editor - Security > Settings > WordPress Tweaks > File Editor
// END iThemes Security - Do not modify or remove this line

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wp_gfob');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Ht0)aJX%c [C]Q[j)C<n71hG4^,|6:! N3Oua4!c#JDL]-D [[do[w^/H{Q=/5/j');
define('SECURE_AUTH_KEY',  'Et1~e%qm^<?p%[dEr&sYB>>OX4t *<uq.%J26G:[5DXYMwBE]h0mAC<|rFdPlUYb');
define('LOGGED_IN_KEY',    '8t=!%AN5~}wzd(Ms::sCVmWU/~ x=9ZCLLP=kGOrpyJ8j(W&`2Xn_,w48+X3Zp/o');
define('NONCE_KEY',        'nk)#y#W4%Vb%;Sf7H#ukT>C9/Xn_Z(kxz/kmHJB*h_W)(Rq7seAF*1Y 5k@E&Y/t');
define('AUTH_SALT',        '$%+}y+Vs=L *Gu4`pLe|H@NGn=3-pdJCV8Hdad:$S83D->>mh>Ut(iVP]X]xQkQ~');
define('SECURE_AUTH_SALT', 'NYQ Zin8UxkCyd0#6MJQ~*>ij*BK70[5=9FJY~pp(?amjm=CZ/Vt~uqv=Fp~}/Uk');
define('LOGGED_IN_SALT',   'XByK{2eGM2?6OF)1cwUSgO0_e8ON3{zB9q;e$H,;YxB9A($ir#z9A5SR0J{*:Wo;');
define('NONCE_SALT',       'DFt:{SOUkcq$MU>:q>]OL:!!1alW97W8e74+bl7[QR<E#)4hWKFfRCTz[o?<2iln');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
